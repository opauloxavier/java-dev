package assembler;

public class FormatedCode {
	
	private String code;
	
	
}
